#ifndef _VOXELS_H_
#define _VOXELS_H_

#include "pandabase.h"
#include "dtoolbase.h"
#include "lvector3.h"

class A
{
private:
	int c;
	LVector3f p;
	
PUBLISHED:
	A() {}
	~A() {}
	
	int sumar(int a, int b) {return a+b;}
	string saludar(string texto) {return texto;}
	string punto(const LVector3f& punto) {return saludar("punto");}

};
#endif
